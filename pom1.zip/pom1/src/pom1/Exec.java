// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Exec.java

package pom1;

import pom1.gui.Gui;

class Exec
{
    Exec()
    {
    }

    public static void main(String args[])
    {
        new Gui();
    }
}
