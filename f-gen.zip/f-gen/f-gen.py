#!/usr/bin/python
## Python gui script for PC controll
## Install python3 python-is-python3 python3-pip python3-tk
## pip install pyserial

import tkinter as tk
from tkinter import ttk

import serial
import time

arduino = serial.Serial(port='/dev/ttyUSB0', baudrate=115200, timeout=.1)

LARGE_FONT= ("Verdana", 12)

mainWindow = tk.Tk()
mainWindow.geometry("400x500")
mainWindow.title('frequency controller')

def sendValue(value):
    arduino.write(bytes(value, 'utf-8'))
    time.sleep(0.05)
    data = arduino.readline()
    print(data)

#===================== Button ======================================

button1 = ttk.Button(mainWindow, text="100Hz", command=lambda: sendValue('100'))
button1.place(x=100, y=100)

button2 = ttk.Button(mainWindow, text="1000Hz", command=lambda: sendValue('1000'))
button2.place(x=100, y=200)

button3 = ttk.Button(mainWindow, text="10000Hz", command=lambda: sendValue('10000'))
button3.place(x=100, y=300)

mainWindow.mainloop()


